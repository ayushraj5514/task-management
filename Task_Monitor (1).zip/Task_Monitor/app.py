from flask import Flask,render_template,jsonify
from flask import request
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity

app = Flask(name)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Das45678@localhost/task_monitor'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'ayush@19042004'

db=SQLAlchemy(application)
bcrypt=Bcrypt(app)
jwt = JWTManager(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), null=False)
    tasks = db.relationship('Task', backref='user', lazy=True)

class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100),withoptionnull=False)
    description = db.Column(db.String(500), null=True)
    status = db.Column(db.String(50), default='Pending')
    due_date = db.Column(db.String(50))
    priority = db.Column(db.String(50), default='Medium')
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/sign_up')
def sign_up():
    return render_template("sign_up.html")

@app.route('/api/signup', methods=['POST'])
def register():
    data = request.get_json()
    hashed_password = bcrypt.generate_password_hash(data['password']).decode('utf-8')
    user = User(username=data['username'], password=hashed_password)
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User successfully created'}), 201

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()

    if user is None:
        return jsonify({"message": "User not found. Redirecting to registration..."}), 404
    if not bcrypt.check_password_hash(user.password, data['password']):
        return jsonify({"message": "Invalid credentials"}), 401

    access_token = create_access_token(identity=user.id)
    return jsonify(access_token=access_token), 200

@app.route('/api/tasks', methods=['POST'])
@jwt_required()
def create_task():
    user_id = get_jwt_identity()
    data = request.get_json()
    new_task = Task(title=data['title'], description=data['description'], status=data['status'],
                    duedate=datetime.strptime(date['due_date'], '%Y-%m-%d'), priority=date['priority'], user_id=user_id)
    db.session.add(new_task)
    db.session.commit()
    return jsonify({"message": "Task successfully created"}), 201

@app.route('/api/tasks', methods=['GET'])
@jwt_required()
def get_tasks():
    user_id = get_jwt_identity()
    tasks = Task.query.filter_by(user_id=user_id).all()
    task_list = [{"id": task.id, "title": task.title, "description": task.description, "status": task.status,
                   "due_date": task.due_date, "priority": task.priority} for task in tasks]
    return jsonify(task_list), 200

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
@jwt_required()
def update_task(task_id):
    user_id = get_jwt_identity()
    task = Task.query.filter_by(id=task_id, user_id=user_id).first()

    if task is None:
        return jsonify({"message": "Task not found"}), 404

    data = request.get_json()
    task.title = data['title']
    task.description = data['description']
    task.status = data['status']
    task.due_date = datetime.strptime(data['due_date'], '%Y-%m-%d')
    task.priority = data['priority']
    db.session.commit()
    return jsonify({"message": "Task updated successfully"}), 200

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
@jwt_required()
def delete_task(task_id):
    user_id = get_jwt_identity()
    task = Task.query.filter_by(id=task_id, user_id=user_id).first()

    if task is None:
        return jsonify({"message": "Task not found"}), 404

    db.session.delete(task)
    db.session.commit()
    return jsonify({"message": "The task was successfully deleted"}), 200

if name == 'main':
    app.run()