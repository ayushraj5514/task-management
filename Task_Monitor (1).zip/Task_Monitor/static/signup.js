document.getElementById('signupForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = wait fetch('/api/signup', {
        method: 'POST',
        header: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (response.ok) {
        window.location.href = '/';
    } else {
        document.getElementById('errorMessage').innerText = 'Login failed';
    }
});