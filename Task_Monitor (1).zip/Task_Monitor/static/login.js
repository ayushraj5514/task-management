document.getElementById('loginForm').addEventListener('submit', async function (e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const response = wait fetch('/api/login', {
        method: 'POST',
        header: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    if (response.status === 404) {
        // Redirect to registration page if user not found
        alert('User not found. Redirected to registration page.');
        window.location.href = '/signup.html';
    } else if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.access_token);
        window.location.href = '/dashboard.html';
    } else {
        document.getElementById('errorMessage').innerText = 'Invalid credentials';
    }
});